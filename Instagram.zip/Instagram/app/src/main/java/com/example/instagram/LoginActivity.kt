package com.example.instagram

class LoginActivity {
}